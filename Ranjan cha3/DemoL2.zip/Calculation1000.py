import decimal
import tkinter as tk
from tkinter import Button, ttk
import pyodbc
import math


def M():
    lists = ["M","W","M","W","M","M","M","W","M","W","M","M","M","W","W","M","M","M","M","W","W","M","W","M","M","M","W","M","M","M","W","W","W","M","W","M","M","M","W","M","W","M","M","M","M","W","W","M"]
    n1= 453
    n2=547
    R=512
    M = (2*(n1*n2)/(n1+n2))+1
    listBox1.insert("", "end", values=("Mean", M))
    nt = 2*n1*n2*(2*n1*n2-n1-n2)
    dt = (n1+n2)*(n1+n2)*(n1+n2-1)
    SD = nt/dt
    #listBox1.insert("", "end", values=("Standard Deviation", math.sqrt(SD)))
    Z= (R-M)/SD
    #listBox1.insert("", "end", values=("z-Statistic", Z))

def SD():
    lists = ["M","W","M","W","M","M","M","W","M","W","M","M","M","W","W","M","M","M","M","W","W","M","W","M","M","M","W","M","M","M","W","W","W","M","W","M","M","M","W","M","W","M","M","M","M","W","W","M"]
    n1= 453
    n2=547
    R=512
    M = (2*(n1*n2)/(n1+n2))+1
   # listBox1.insert("", "end", values=("Mean", M))
    nt = 2*n1*n2*(2*n1*n2-n1-n2)
    dt = (n1+n2)*(n1+n2)*(n1+n2-1)
    SD = nt/dt
    listBox1.insert("", "end", values=("Standard Deviation", math.sqrt(SD)))
    Z= (R-M)/SD
   # listBox1.insert("", "end", values=("z-Statistic", Z))

def Z():
    lists = ["M","W","M","W","M","M","M","W","M","W","M","M","M","W","W","M","M","M","M","W","W","M","W","M","M","M","W","M","M","M","W","W","W","M","W","M","M","M","W","M","W","M","M","M","M","W","W","M"]
    n1= 453
    n2=547
    R=512
    M = (2*(n1*n2)/(n1+n2))+1
   # listBox1.insert("", "end", values=("Mean", M))
    nt = 2*n1*n2*(2*n1*n2-n1-n2)
    dt = (n1+n2)*(n1+n2)*(n1+n2-1)
    SD = nt/dt
    #listBox1.insert("", "end", values=("Standard Deviation", math.sqrt(SD)))
    Z= (R-M)/SD
    listBox1.insert("", "end", values=("z-Statistic", Z))

scores = tk.Tk()
scores['bg']='#deb70b'
label1 = tk.Label(scores, text="Run Test(Mean & Standard Daviation Calculation)", font=("Arial bold",10)).grid(row=0, columnspan=4)
button1= Button(scores,text="Mean Calculation",width=30,height=2,command=M).grid(row=1,column=0)
button2= Button(scores,text="Standard Calculation",width=30,height=2,command=SD).grid(row=1,column=1)
button3= Button(scores,text="z-Statistic",width=30,height=2,command=Z).grid(row=1,column=2)
cols = ('Label', 'Value')
listBox1 = ttk.Treeview(scores, columns=cols, show='headings',height=4)
for col in cols:
    listBox1.heading(col, text=col)
listBox1.grid(row=3, column=0,columnspan=4)


scores.mainloop()