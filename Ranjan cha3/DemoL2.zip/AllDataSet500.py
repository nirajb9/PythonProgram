import tkinter as tk
from tkinter import ttk
import pyodbc

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=MUM-NIRAJB1;'
                      'Database=DemoDB2;'
                      'Trusted_Connection=True'
                      )
                      

cursor = conn.cursor()
cursor.execute('select * from Table_2')

def Percent(value,total):
    return round((value*100)/total)

def show():
    #for row in cursor:
  
   for index, row in enumerate(cursor):
        listBox1.insert("", "end", values=(row[0], row[1], row[2], row[3], row[4],row[5], row[6], row[7], row[8], row[9])) 
scores = tk.Tk()
scores['bg']='#deb70b'
label1 = tk.Label(scores, text="Run Test DataSet", font=("Arial bold",10)).grid(row=0, columnspan=3)
cols = ('1', '2','3','4','5','6', '7','8','9','10')
listBox1 = ttk.Treeview(scores, columns=cols, show='headings',height=20,selectmode='browse')

verscrbar = ttk.Scrollbar(scores,orient="vertical",command=listBox1.yview)
listBox1.configure(yscrollcommand=verscrbar.set)

i=0
for col in cols:
    listBox1.heading(col, text=col) 
    listBox1.column('# '+ str(i),width=50)
    i=i+1
listBox1.grid(row=1, column=0,columnspan=4)
verscrbar.grid(column=5, row=1, sticky='ns')

show()
scores.mainloop()