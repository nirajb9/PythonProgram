from cgi import test
from multiprocessing.managers import BaseManager
from optparse import Values
import tkinter as tk
from tkinter import ttk
import pyodbc
import math
import statistics

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=MUM-NIRAJB1;'
                      'Database=KruskalWallisDB;'
                      'Trusted_Connection=True'
                      )



data1 = [1, 3, 4, 5, 7, 9, 2]
def Multiply(value1,value2):
    return round((value1*value2),2)

def CalculatetTest(m1,m2,sd1,sd2,length):
    up = (m2-m1)-15
    dsqrt = math.sqrt(((sd1*sd1)/length) + ((sd2*sd2)/length))
    ttest = up/dsqrt
    print(ttest)


def show1():
   lst1 = []
   lst2 = []
   lst3 = []
   cursor = conn.cursor()
   cursor.execute('select * from Table_1')
   for index, row in enumerate(cursor):
       lst1.append(row[1])
       lst2.append(row[2])
       lst3.append(row[3])
   Mean1 = statistics.mean(lst1)
   Mean2 = statistics.mean(lst2)
   Mean3 = statistics.mean(lst3)
   SD1 = statistics.stdev(lst1)
   SD2 =statistics.stdev(lst2)
   SD3 =statistics.stdev(lst3)
  # CalculatetTest(GMean,BMean,GSD,BSD,len(lst1))
  # x=1
   cursor1 = conn.cursor()
   cursor1.execute('select * from Table_1')
   for index, row in enumerate(cursor1):
       listBox1.insert("", "end", values=(row[0], row[1],row[2],row[3]))
      
   listBox1.insert("", "end", values=("Mean",Mean1,Mean2,Mean3))
   listBox1.insert("", "end", values=("SD", round(SD1,2), round(SD2,2),round(SD3,2)))
   
      
scores = tk.Tk()
scores['bg']='#8000ff'
label1 = tk.Label(scores, text="Kruskal Wallis Test", font=("Arial bold",10)).grid(row=0, columnspan=1)
cols = ('SNo', 'No Exercise', 'Exercise 20 Minutes', 'Exercise 40 Minutes')
listBox1 = ttk.Treeview(scores, columns=cols, show='headings',height=10)
for col in cols:
    listBox1.heading(col, text=col)
listBox1.grid(row=1, column=0,columnspan=1)



show1()
scores.mainloop()