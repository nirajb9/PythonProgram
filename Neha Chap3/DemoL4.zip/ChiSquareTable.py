from cgi import test
from multiprocessing.managers import BaseManager
from optparse import Values
import tkinter as tk
from tkinter import ttk
import pyodbc
import math
import statistics
from PIL import ImageTk,Image  

def show1():
 
   listBox2.insert("", "end", values=(1, 3.84))
   listBox2.insert("", "end", values=(2, 5.99))
   listBox2.insert("", "end", values=(3, 7.82))
  
scores = tk.Tk()
scores['bg']='#8000ff'

label2 = tk.Label(scores, text="Kruskal-Wallis", font=("Arial bold",10)).grid(row=2, columnspan=1)
cols1 = ('df', 'P=0.05')
listBox2 = ttk.Treeview(scores, columns=cols1, show='headings',height=3)
for col in cols1:
    listBox2.heading(col, text=col)
listBox2.grid(row=3, column=0,columnspan=1)

x = 'I1.png'
img = Image.open(x)
img = img.resize((700, 500), Image.ANTIALIAS)
img = ImageTk.PhotoImage(img)
panel = tk.Label(scores, image=img).grid(row=9, columnspan=1)

show1()

scores.mainloop()