from cgi import test
from multiprocessing.managers import BaseManager
from optparse import Values
from re import I
import tkinter as tk
from tkinter import ttk
import pyodbc
import math
import statistics

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=MUM-NIRAJB1;'
                      'Database=KruskalWallisDB;'
                      'Trusted_Connection=True'
                      )



data1 = [1, 3, 4, 5, 7, 9, 2]
def Multiply(value1,value2):
    return round((value1*value2),2)

def CalculatetTest(m1,m2,sd1,sd2,length):
    up = (m2-m1)-15
    dsqrt = math.sqrt(((sd1*sd1)/length) + ((sd2*sd2)/length))
    ttest = up/dsqrt
    print(ttest)


def show1():
   lst1 = []
   lst2 = []
   lst3 = []
   sumlst1= 0
   sumlst2= 0
   sumlst3= 0
   cursor = conn.cursor()
   cursor.execute('select * from Table_2')
   for index, row in enumerate(cursor):
       lst1.append(row[1])
       sumlst1 = sumlst1 +row[1]
       lst2.append(row[2])
       sumlst2 = sumlst2 +row[2]
       lst3.append(row[3])
       sumlst3 = sumlst3 +row[3]
   Mean1 = statistics.mean(lst1)
   Mean2 = statistics.mean(lst2)
   Mean3 = statistics.mean(lst3)
   SD1 = statistics.stdev(lst1)
   SD2 =statistics.stdev(lst2)
   SD3 =statistics.stdev(lst3)
  # CalculatetTest(GMean,BMean,GSD,BSD,len(lst1))
  # x=1
   cursor1 = conn.cursor()
   cursor1.execute('select * from Table_1')
   i=0
   for index, row in enumerate(cursor1):
       listBox1.insert("", "end", values=(row[0], str(row[1])+"("+ str(lst1[i])+")",str(row[2])+"("+ str(lst2[i])+")",str(row[3])+"("+ str(lst3[i])+")"))
       i=i+1
      
   listBox1.insert("", "end", values=("Mean",Mean1,Mean2,Mean3))
   listBox1.insert("", "end", values=("SD", round(SD1,2), round(SD2,2),round(SD3,2)))
   listBox1.insert("", "end", values=("Sum",sumlst1,sumlst2,sumlst3))

   listBox2.insert("", "end", values=("TC Calculation",'4113.56'))
   listBox2.insert("", "end", values=("H Clculation",'7.27'))

 
   
      
scores = tk.Tk()
scores['bg']='#8000ff'
label1 = tk.Label(scores, text="Kruskal Wallis Test", font=("Arial bold",10)).grid(row=0, columnspan=1)
cols = ('SNo', 'No Exercise', 'Exercise 20 Minutes', 'Exercise 40 Minutes')
listBox1 = ttk.Treeview(scores, columns=cols, show='headings',height=15)
for col in cols:
    listBox1.heading(col, text=col)
listBox1.grid(row=1, column=0,columnspan=1)

label2 = tk.Label(scores,text="Kruskal Wallis Test Calculation", font=("Arial bold",10)).grid(row=0, columnspan=1)
cols1 =('Name', 'Value')
listBox2 = ttk.Treeview(scores,columns=cols1, show='headings',height=5)
for col in cols1:
    listBox2.heading(col,text=col)
listBox2.grid(row=2, column=0, columnspan=1)


show1()
scores.mainloop()