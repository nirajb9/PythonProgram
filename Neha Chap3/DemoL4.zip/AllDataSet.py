import tkinter as tk
from tkinter import ttk
import pyodbc

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=MUM-NIRAJB1;'
                      'Database=KruskalWallisDB;'
                      'Trusted_Connection=True'
                      )

cursor = conn.cursor()
cursor.execute('select * from Table_1')

def show():
    
   for index, row in enumerate(cursor):
        listBox1.insert("", "end", values=(row[0], row[1],row[2],row[3])) 
scores = tk.Tk()
scores['bg']='#8000ff'
label1 = tk.Label(scores, text="Kruskal-Wallis Test", font=("Arial bold",10)).grid(row=0, columnspan=3)
cols = ('SNo', 'No Exercise', 'Exercise 20 Minutes', 'Exercise 40 Minutes')
listBox1 = ttk.Treeview(scores, columns=cols, show='headings',height=15)
for col in cols:
    listBox1.heading(col, text=col) 
listBox1.grid(row=1, column=0,columnspan=4)

show()
scores.mainloop()